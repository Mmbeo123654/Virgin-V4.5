package bre2el.fpsreducer.gui.font;

public record Glyph(int u, int v, int width, int height, char value, GlyphMap owner) {
}
