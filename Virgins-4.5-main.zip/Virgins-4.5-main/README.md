<h1 align="center">Virgins 4.5 | Buildable source</h1>

## $19 skidded "ghost" client 
Fully deobfuscated and remapped in a whole ass minute :sob::pray: <br>

<br>

**Trillium INC: https://discord.gg/vzXzFpv2gk**

## Why?

This guy keeps getting his jar leaked in very unique ways, he also did not even use renamer. 
he also only obfuscated the mixins and went on with his day.

lvstrng here:
his obfuscator sucks so bad a normal narumii config completely deobfuscated it. they probably looked at the classes through a decompiler and said to themselves:
"wow this obfuscator made my methods and fields invisible with synthetics and bridges! let's release the new update and say we improved the obf!!!!!!!!!!!!!!!"
(the only thing that caused us struggle was jnic that he paid 150 euro for). virgin and his team keeps bragging about how they don't skid. they skidded BlockIterator,
BlockEntityIterator and other classes required for these two from meteor client. he skidded the mod replace method for selfdestruct from argon (he didn't bother to
change parameter names/method name at all, that's why I am guessing). he has copied the script api from chatgpt i think, since virgins native language isn't english
and the methods in the scripting classes are named as if they were meant to get nuclear launch codes. credits to ablue for doing something i was lazy to do,
which was actually to fix all the issues that came with deobfuscating and remapping the client.

## How To Use

you on yo own with this one :sob::pray:

## Credits

virgins1337 (644151743546130433) - Making this client. <br>
lvstrng - deobfuscation + most remapping.<br>
ablue - remapping and making it buildable.<br>
? - jar (this dumbo leaked his jar in ratscanner)<br>

## HALL OF STUPIDNESS

![image](https://github.com/user-attachments/assets/3e9152b3-23c3-4fbd-b219-9abf920c3354)
![image](https://github.com/user-attachments/assets/e44be45e-7bbc-4ddb-b059-d7c9987c0fed)

<h3> Running DeadCodeCleanTransformer transformer </h3>
<h3> Made 8735 changes </h3>
<h3> Ended DeadCodeCleanTransformer transformer in 409 ms </h3>

<h3>Running LocalVariableNamesCleanTransformer transformer </h3>
<h3>Made 1328 changes </h3>
<h3>Ended LocalVariableNamesCleanTransformer transformer in 1 ms </h3>
